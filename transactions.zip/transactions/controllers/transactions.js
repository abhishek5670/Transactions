// import Transactions from '../models/transactions.js';
import mongoose from 'mongoose';
import { v4 } from 'uuid';
import creditAccount from '../utils/credit.js';
import debitAccount from '../utils/debit.js';


const transfer = async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction()
  try {
      const { toUsername, fromUsername, amount, summary} = req.body;
      const reference = v4();
      if (!toUsername && !fromUsername && !amount && !summary) {
          return res.status(400).json({
              status: false,
              message: 'Please provide the following details: toUsername, fromUsername, amount, summary'
          })
      }
      

    const transferResult = await Promise.all([
      debitAccount(
        {amount, username:fromUsername, purpose:"transfer", reference, summary,
        trnxSummary: `TRFR TO: ${toUsername}. TRNX REF:${reference} `, session}),
      creditAccount(
        {amount, username:toUsername, purpose:"transfer", reference, summary,
        trnxSummary:`TRFR FROM: ${fromUsername}. TRNX REF:${reference} `, session})
    ]);
   

    const failedTxns = transferResult.filter((result) => result.status !== true);
    if (failedTxns.length) {
      const errors = failedTxns.map(a => a.message);
      await session.abortTransaction();
      return res.status(400).json({
          status: false,
          message: errors
      })
    }
    

    await session.commitTransaction();
    session.endSession();

    return res.status(201).json({
      status: true,
      message: 'Transfer successful'
  })
  } catch (err) {
      await session.abortTransaction();
      session.endSession();

      return res.status(500).json({
          status: false,
          message: `Unable to find perform transfer. Please try again. \n Error: ${err}`
      })
  }
}

export default { transfer };